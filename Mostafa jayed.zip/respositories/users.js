const { User } = require('../models');

module.exports = {
    getAllUsers() {
        return User.findAll()
    },
    // methods to implement
    getUsers(offset = 0, limit = 10) {
        return User.findAll({
            limit: Number(limit) || 10,
            offset: Number(offset) || 0,
            order: [
                ['id', 'DESC']
            ]
        })
    },
    getAdmins() {
        return User.findAll({ where: { role: 'admin' } });
    },
    getAuthors() {
        return User.findAll({ where: { role: 'author' } });
    },
    getGuests() {
        return User.findAll({ where: { role: 'guest' } });
    },
    getUser(id) {
        return User.findOne({ where: { id } })
    },
    getUserByEmail(email) {
        return User.findOne({ where: { email } })
    },
    addUser(user) {
        return User.create(user);
    },
    updateUser(uid, data) {
        return User.findOne({ where: { id: uid } }).then(user => {
            if (user) {
                return user.update({ ...data });
            } else {
                throw new Error("user Not Found");
            }
        })
    },
    deleteUser(id) {
        return User.destroy({ where: { id } })
    },
    // Other methods deemed useful
}