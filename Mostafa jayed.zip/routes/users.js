const router = require('express').Router();
const usersRepo = require('../respositories/users')

/* GET users listing. */
router.get('/', async function (req, res, next) {
  res.send(await usersRepo.getUsers(req.query.offset, req.query.limit))
});

/* GET single user. */
router.get('/:id', async function (req, res, next) {
  res.send(await usersRepo.getUser(req.params.id));
});

/* POST user. */
router.post('/', async function (req, res, next) {
  console.log(req.body);
  res.send(await usersRepo.addUser(req.body))
});

/* PUT user. */
router.put('/', async function (req, res, next) {
  res.send(await usersRepo.updateUser(req.body.id, req.body));
});

// DELETE User
router.delete('/:id', async function (req, res, next) {
  try {
    await usersRepo.deleteUser(req.params.id).catch(err => {
      return res.send(err);
    })
    res.send("Deleted Successfully !");
  } catch (err) {
    res.send(err);
  }
});

module.exports = router;
