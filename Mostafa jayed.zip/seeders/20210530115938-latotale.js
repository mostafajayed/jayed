'use strict';
const faker = require('faker');

module.exports = {
  up: async (queryInterface, Sequelize) => {

    /// USERS ///
    let users = [];
    for (let i = 0; i < 20; i++) {
      let username = faker.name.firstName() + ' ' + faker.name.lastName();
      let email = faker.internet.email();
      let password = faker.internet.password();
      let updatedAt = faker.date.recent(faker.datatype.number({ min: 1, max: 60 }))
      let createdAt = faker.date.past(faker.datatype.number({ min: 1, max: 21 }), updatedAt);
      users.push({
        id: i + 1,
        username,
        email,
        password,
        role: faker.random.arrayElement(['admin', 'author', 'guest']),
        createdAt,
        updatedAt
      });
    }

    await queryInterface.bulkInsert('Users', users, {});


    // TAGS //
    let tags = [];
    for (let i = 0; i < 10; i++) {
      let updatedAt = faker.date.recent(faker.datatype.number({ min: 1, max: 60 }))
      let createdAt = faker.date.past(faker.datatype.number({ min: 1, max: 21 }), updatedAt);
      tags.push({
        id: i + 1,
        name: `${faker.music.genre().split(" ")[0]} ${faker.name.title().split(" ")[0]} ${faker.lorem.word().split(" ")[0]}`,
        createdAt,
        updatedAt
      })
    }

    await queryInterface.bulkInsert('Tags', tags, {});


    // ARTICLES //
    let articles = [];
    let initId = 1;
    users.map(u => {
      let creationDate = faker.date.between(u.createdAt, faker.date.recent());
      for (let i = 0; i < faker.datatype.number({ min: 2, max: 10 }); i++) {
        articles.push({
          id: initId++,
          UserId: u.id,
          title: faker.name.title(),
          content: faker.lorem.paragraphs(faker.datatype.number({ min: 2, max: 5 })),
          published: faker.datatype.boolean(),
          createdAt: creationDate,
          updatedAt: faker.date.between(creationDate, new Date())
        });
      }
    });

    await queryInterface.bulkInsert('Articles', articles, {});



    // ArticleTags //
    let articleTags = [];
    articles.map(a => {
      let insertedTags = [];
      for (let i = 0; i < faker.datatype.number({ min: 2, max: 6 }); i++) {

        // make sure same article does not get tagged twice with same tag
        let t = faker.random.arrayElement(tags);
        while (insertedTags.find(t_ => t_ === t.id)) {
          t = faker.random.arrayElement(tags);
        }


        let creationDate = faker.date.between(a.createdAt, a.updatedAt);
        articleTags.push({
          ArticleId: a.id,
          TagId: t.id,
          createdAt: creationDate,
          updatedAt: creationDate
        });
        insertedTags.push(t.id);
      }
    });

    await queryInterface.bulkInsert('ArticleTags', articleTags, {});

    ///// COMMENTS ///
    let comments = [];
    articles.map(a => {
      for (let i = 0; i < faker.datatype.number({ min: 0, max: 10 }); i++) {
        let createdAt = faker.date.between(a.createdAt, faker.date.recent());
        let updatedAt = faker.date.between(createdAt, new Date());
        comments.push({
          content: faker.lorem.sentence(faker.datatype.number({ min: 2, max: 10 })),
          createdAt,
          updatedAt,
          ArticleId: a.id,
          UserId: faker.random.arrayElement(users).id
        })
      }
    });

    return await queryInterface.bulkInsert('Comments', comments, {});

  },

  down: async (queryInterface, Sequelize) => {
  }
};
